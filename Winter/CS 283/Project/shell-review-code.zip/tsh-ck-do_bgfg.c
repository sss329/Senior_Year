/*
* do_bgfg - Execute the builtin bg and fg commands
*/
void do_bgfg(char **argv)
 {

  /* if bg command */
    /* send SIGCONT */
    /* mark as background job */
  /* else if fg command */
    /* send SIGCONT */
    /* mark as foreground job */
  return;
 }
